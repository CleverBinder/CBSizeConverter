//
//  CBSizeConverter.h
//  CBSizeConverter
//
//  Created by Morten Jeppesen on 19/02/16.
//  Copyright © 2016 CleverBinder A/S. All rights reserved.
//

#import <Foundation/Foundation.h>
//

@interface CBSizeConverter : NSObject

-(id)start;
-(int)getFromInch:(int)inch;
@end
